/*Assignment5_seg2105
* Name: Qunshu Fei
* Project Name: UpdatedCalculator
* The main object of this assignment is to improve some ideas of assignment4
* Based on Assignment4, there are couple problems such as
* The calculator can not accept continuous calculations
* The screen of the calculator is disorganized
* etc
* */

package com.example.updatedcalculator;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.ButtonBarLayout;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    Button btndel, btnclear, btn7, btn8, btn9,btn0,btn1,btn2,btn3,btn4,btn5,btn6, btnadd,
            btnsub, btnmul, btndiv, btnsqure, btndot, btnequal;

    EditText edresult;
    double value1, value2, res;
    String operation;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        typeCast();

        btn1.setOnClickListener(this);
        btn2.setOnClickListener(this);
        btn3.setOnClickListener(this);
        btn4.setOnClickListener(this);
        btn5.setOnClickListener(this);
        btn6.setOnClickListener(this);
        btn7.setOnClickListener(this);
        btn8.setOnClickListener(this);
        btn9.setOnClickListener(this);
        btn0.setOnClickListener(this);
        btnadd.setOnClickListener(this);
        btnsub.setOnClickListener(this);
        btnmul.setOnClickListener(this);
        btndiv.setOnClickListener(this);
        btnequal.setOnClickListener(this);
        btnsqure.setOnClickListener(this);
        btndot.setOnClickListener(this);
        btnclear.setOnClickListener(this);
        btndel.setOnClickListener(this);
    }

    public void typeCast(){
        edresult = (EditText) findViewById(R.id.myText);
        btndel = (Button) findViewById(R.id.del);
        btnclear = (Button) findViewById(R.id.clear);
        btn0 = (Button) findViewById(R.id.num0);
        btn1 = (Button) findViewById(R.id.num1);
        btn2 = (Button) findViewById(R.id.num2);
        btn3 = (Button) findViewById(R.id.num3);
        btn4 = (Button) findViewById(R.id.num4);
        btn5 = (Button) findViewById(R.id.num5);
        btn6 = (Button) findViewById(R.id.num6);
        btn7 = (Button) findViewById(R.id.num7);
        btn8 = (Button) findViewById(R.id.num8);
        btn9 = (Button) findViewById(R.id.num9);
        btnadd = (Button) findViewById(R.id.add);
        btnsub = (Button) findViewById(R.id.sub);
        btnmul = (Button) findViewById(R.id.mul);
        btndiv = (Button) findViewById(R.id.div);
        btnsqure = (Button) findViewById(R.id.squre);
        btndot = (Button) findViewById(R.id.dot);
        btnequal = (Button) findViewById(R.id.equal);

    }

    @Override
    public void onClick(View v){
        if (v.getId() == R.id.num1){
            edresult.setText(edresult.getText()+"1");
        }
        else if (v.getId() == R.id.num2){
            edresult.setText(edresult.getText()+"2");
        }
        else if (v.getId() == R.id.num3){
            edresult.setText(edresult.getText()+"3");
        }
        else if (v.getId() == R.id.num4){
            edresult.setText(edresult.getText()+"4");
        }
        else if (v.getId() == R.id.num5){
            edresult.setText(edresult.getText()+"5");
        }
        else if (v.getId() == R.id.num6){
            edresult.setText(edresult.getText()+"6");
        }
        else if (v.getId() == R.id.num7){
            edresult.setText(edresult.getText()+"7");
        }
        else if (v.getId() == R.id.num8){
            edresult.setText(edresult.getText()+"8");
        }
        else if (v.getId() == R.id.num9){
            edresult.setText(edresult.getText()+"9");
        }
        else if (v.getId() == R.id.num0){
            edresult.setText(edresult.getText()+"0");
        }
        else if (v.getId() == R.id.dot){
            edresult.setText(edresult.getText()+".");
        }
        else if (v.getId() == R.id.del){
            if(!edresult.getText().toString().equals("")){
                String value = edresult.getText().toString();
                if(value.length()>0){
                    value = value.substring(0,value.length()-1);
                    edresult.setText(value);
                }
            }
        }
        else if (v.getId() == R.id.clear){
            edresult.setText("");
        }
        else if (v.getId() == R.id.add){
            value1 = Integer.parseInt(edresult.getText().toString());
            operation = "+";
            edresult.setText("");
        }
        else if (v.getId() == R.id.sub){
            value1 = Integer.parseInt(edresult.getText().toString());
            operation = "-";
            edresult.setText("");
        }
        else if (v.getId() == R.id.mul){
            value1 = Integer.parseInt(edresult.getText().toString());
            operation = "*";
            edresult.setText("");
        }
        else if (v.getId() == R.id.div){
            value1 = Integer.parseInt(edresult.getText().toString());
            operation = "/";
            edresult.setText("");
        }
        else if (v.getId() == R.id.equal){
            value2 = Integer.parseInt(edresult.getText().toString());
            switch(operation){
                case "+":
                    res = value1+value2;
                    edresult.setText(res + "");
                    break;
                case "-":
                    res = value1-value2;
                    edresult.setText(res + "");
                    break;
                case "*":
                    res = value1*value2;
                    edresult.setText(res + "");
                    break;
                case "/":
                    res = value1/value2;
                    edresult.setText(res + "");
                    break;
                    /*each case here will show different operations and their final results*/
            }
        }
        else if (v.getId() == R.id.squre){
            double value = Integer.parseInt(edresult.getText().toString());
            double ress = Math.sqrt(value);
            edresult.setText(ress+"");
            /*this is for the operation squareroot which is the button ^0.5 on the screen*/
        }
    }
}